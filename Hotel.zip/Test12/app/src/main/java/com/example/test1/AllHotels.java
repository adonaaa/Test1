package com.example.test1;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class AllRestActivity extends AppCompatActivity {

    private RecyclerView recyclerView ;
    MyRecyclerViewAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_hotels);

        // data to populate the RecyclerView with
        ArrayList<String> HotelNames = new ArrayList<>();
        HotelNames.add("Helton");
        HotelNames.add("Ramada");
        HotelNames.add("Plaza");
        HotelNames.add("Golden Crown");
        HotelNames.add("Sheraton");

        // set up the RecyclerView
        RecyclerView recyclerView = findViewById(R.id.rvRestsAllHotel);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new MyRecyclerViewAdapter(this, HotelNames);
        recyclerView.setAdapter(adapter);
    }
}
